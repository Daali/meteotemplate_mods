<?php
// meteogram settings file
// Version: 3.3
// Created: 2021-08-10 13:54:43

$meteogramLocations = 'Arcade,lat=34.07789&lon=-83.56155&altitude=267;Braselton,lat=34.10927&lon=-83.76267&altitude=277;Commerce,lat=34.204&lon=-83.45711&altitude=278;Gainesville,lat=34.29788&lon=-83.82407&altitude=381';
$resolution = '1h';
$iconPosition = 'normal';
$windChartHeight = '30';
$separation = '5';


