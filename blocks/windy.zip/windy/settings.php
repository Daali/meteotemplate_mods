<?php
// windy settings file
// Version: 1.2
// Created: 2021-07-31 23:15:00

$windyOverlay = 'radar';


