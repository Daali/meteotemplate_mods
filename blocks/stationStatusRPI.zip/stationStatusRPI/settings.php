<?php
// stationStatus settings file
// Version: 1.1
// Created: 2016-06-28 11:35:04

$maxInterval = '900';


